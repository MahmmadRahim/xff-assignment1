# XFF Assignment – Web Platform Intern

## 🔧 Technologies Used
- Backend: Spring Boot (Java)
- Frontend: HTML, CSS, JavaScript

---

## ▶️ How to Run the Project

### Backend (Spring Boot)
1. Unzip the downloaded project.
2. Open the backend folder in any IDE (like IntelliJ IDEA or Eclipse).
3. Make sure you have Java 17+ and Maven installed.
4. In terminal, run:
   ```bash
   ./mvnw spring-boot:run
   ```
5. Backend will start on:  
   `http://localhost:8080`

---

### Frontend
1. Navigate to the frontend folder inside the unzipped project.
2. Open `index.html` directly in your browser.
3. It will interact with the backend via API.

---

## 📁 Folder Structure
```
xff-assignment/
├── backend/
│   └── src/...
├── frontend/
│   └── index.html
└── README.md
```

---

## 👤 Submitted By
- Name: Mahmmad Rahim
- Email: mahmmadrahim@gmail.com